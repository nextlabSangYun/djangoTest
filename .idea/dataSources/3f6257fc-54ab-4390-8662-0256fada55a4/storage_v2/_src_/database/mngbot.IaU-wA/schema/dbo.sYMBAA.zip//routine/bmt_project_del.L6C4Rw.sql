-- =============================================
-- Author:		이경훈
-- Create date: 2018.02.28
-- Description:	프로젝트 삭제
-- =============================================
CREATE PROCEDURE [dbo].[BMT_PROJECT_DEL]
	@PID VARCHAR(12),
		@modId VARCHAR(5),
        @out_Return INT OUTPUT -- 오류:0, 성공:1
	
AS
DECLARE @projectcnt int
SELECT @projectcnt = COUNT(*) FROM tb_project WHERE pid = @PID

BEGIN

  SET NOCOUNT ON;
	
	IF @projectcnt > 0
	   
	   BEGIN TRY
	     BEGIN TRAN 

		     -- 프로젝트 삭제여부 N
		     UPDATE tb_project SET use_yn = 'N', project_stat = 'C304', mod_id = @modId, mod_dtm = getdate() WHERE pid = @PID

		     --  BMT 결과 DATA 삭제
		     MERGE INTO TB_BMT m
		     USING (SELECT b.xqms_seq 
			     FROM TB_BMT a
			    INNER JOIN TB_XQMS b ON (b.XQMS_SEQ = a.XQMS_SEQ)
			    WHERE b.pid = @PID) v
			ON (m.xqms_seq = v.xqms_seq)
		      WHEN MATCHED THEN
			DELETE;	
		     
		     --  채널변경시간결과 DATA 삭제
		     MERGE INTO TB_CHANNEL m
		     USING (SELECT b.xqms_seq 
			      FROM TB_CHANNEL a
			     INNER JOIN TB_XQMS b ON (b.XQMS_SEQ = a.XQMS_SEQ)
			     WHERE b.pid = @PID) v
			ON (m.xqms_seq = v.xqms_seq)
		     WHEN MATCHED THEN
			DELETE;

		     --  UI반응시간 DATA 삭제
		     MERGE INTO TB_COLD_RESET m
		     USING (SELECT b.xqms_seq 
			      FROM TB_COLD_RESET a
			     INNER JOIN TB_XQMS b ON (b.XQMS_SEQ = a.XQMS_SEQ)
			     WHERE b.pid = @PID) v
			ON (m.xqms_seq = v.xqms_seq)
		     WHEN MATCHED THEN
			DELETE;	 

		     --  측정결과첨부파일 DATA 삭제
		     MERGE INTO TB_XQMS_ATTACH m
		     USING (SELECT b.xqms_seq, a.seq 
			      FROM TB_XQMS_ATTACH a
			     INNER JOIN TB_XQMS b ON (b.XQMS_SEQ = a.XQMS_SEQ)
			     WHERE b.pid = @PID) v
			ON (m.xqms_seq = v.xqms_seq AND m.seq = v.seq)
		     WHEN MATCHED THEN
		       DELETE;	

		     -- TC측정이력 DATA 삭제
		     DELETE FROM TB_XQMS WHERE pid = @PID

	      COMMIT TRAN
	      SET @out_Return = 1

	   END TRY
	   BEGIN CATCH
         ROLLBACK TRAN 
		 SET @out_Return = 0

		 SELECT '오류' AS '결과'
		      , ERROR_MESSAGE() AS '오류메시지'
		      , ERROR_LINE() AS '오류 줄번호'
		      , ERROR_NUMBER() AS '오류번호'
		      , ERROR_STATE() AS '오류 상태코드'
		      , @@ERROR AS '오류 줄번호'
	   END CATCH
RETURN
END
go

