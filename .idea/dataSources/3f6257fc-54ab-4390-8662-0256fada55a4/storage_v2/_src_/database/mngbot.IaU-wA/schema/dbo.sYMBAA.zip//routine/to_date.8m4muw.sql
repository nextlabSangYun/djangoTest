CREATE FUNCTION [dbo].[to_date]
               (@date_string VARCHAR(16),
                   @pattern_param VARCHAR(16))
RETURNS datetime
AS
  BEGIN
    DECLARE @result datetime
    DECLARE @pattern VARCHAR(21)
    SET @pattern = UPPER(@pattern_param)
    
    IF (@pattern = 'YYYYMMDDHH24MISS') 
		BEGIN
			SET @result = convert(datetime, SUBSTRING(@date_string, 1, 8), 112) + convert(datetime, SUBSTRING(@date_string, 9, 2) + ':' + SUBSTRING(@date_string, 11, 2) + ':' + SUBSTRING(@date_string, 13, 2), 13)
		END
    ELSE IF (@pattern = 'YYYYMMDD')
		BEGIN
			SET @result = convert(datetime, SUBSTRING(@date_string, 1, 8), 112)
		END
	ELSE 
		BEGIN
			SET @result = null
		END
    
    RETURN @result
  END
go

