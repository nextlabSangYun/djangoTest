CREATE FUNCTION [dbo].[to_char]
               (@datetime_param datetime,
                   @pattern_param VARCHAR(16))
RETURNS varchar(14)
AS
  BEGIN
    DECLARE @result varchar(14)
    DECLARE @pattern VARCHAR(21)
    SET @pattern = UPPER(@pattern_param)
    
    IF (@pattern = 'YYYYMMDDHH24MISS') 
        BEGIN
            SET @result = CONVERT(varchar(8), @datetime_param, 112) + REPLACE(CONVERT(varchar(8), @datetime_param, 108), ':', '')
        END
    ELSE IF (@pattern = 'YYYYMMDD')
        BEGIN
            SET @result = CONVERT(varchar(8), @datetime_param, 112)
        END
    ELSE IF (@pattern = 'YYMMDD')
        BEGIN
            SET @result = CONVERT(varchar(6), @datetime_param, 12)
        END
    ELSE 
        BEGIN
            SET @result = null
        END
    
    RETURN @result
  END
go

