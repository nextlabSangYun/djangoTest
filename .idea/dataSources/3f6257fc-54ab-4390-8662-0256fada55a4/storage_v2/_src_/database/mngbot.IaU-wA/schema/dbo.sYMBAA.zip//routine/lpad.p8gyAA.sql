CREATE FUNCTION [dbo].[lpad] (@sSrcValue nvarchar(20), @nSize int, @sChar nvarchar(2))
RETURNS NVARCHAR (100)
AS
BEGIN
RETURN (ISNULL( REPLICATE(@sChar, @nSize-len(@sSrcValue))+@sSrcValue, substring(@sSrcValue,len(@sSrcValue)-@nSize+1,len(@sSrcValue))))

END
go

