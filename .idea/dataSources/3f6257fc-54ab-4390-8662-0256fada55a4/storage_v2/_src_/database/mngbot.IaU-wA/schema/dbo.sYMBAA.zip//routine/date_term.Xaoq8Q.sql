CREATE FUNCTION [dbo].[date_term]
               (@datetime2 datetime, @datetime1 datetime)
RETURNS int
AS
  BEGIN
    DECLARE @result int
    DECLARE @termMillis int
    SET @result = 0
    SET @termMillis = DATEDIFF(S, '19700101', @datetime2) - DATEDIFF(S, '19700101', @datetime1);
    SET @result = @termMillis / 86400 + 1 
    RETURN @result
  END
go

